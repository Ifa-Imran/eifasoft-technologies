'use client';

import { useReadContract, useWriteContract, useWaitForTransactionReceipt, useAccount } from 'wagmi';
import { useQueryClient } from '@tanstack/react-query';
import { contracts, KAIRO_DECIMALS } from '@/config/contracts';
import { CoreMembershipSubscriptionABI } from '@/config/abis/CoreMembershipSubscription';
import { useToast } from '@/components/ui/Toast';
import { formatUnits } from 'viem';
import { useEffect } from 'react';
// v29 contracts auto-compound on subscribe/claim — no post-action needed

export function useCMS() {
  const { address } = useAccount();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Global total subscriptions sold
  const { data: totalSubs, isLoading: countLoading, queryKey: totalSubsKey } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'totalSubscriptions',
    query: {
      enabled: contracts.cms !== '0x',
      refetchInterval: 15000,
    },
  });

  // Per-user subscription count
  const { data: userSubCount, queryKey: userSubCountKey } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'getSubscriptionCount',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address && contracts.cms !== '0x',
      refetchInterval: 15000,
    },
  });

  const { data: claimable, queryKey: claimableKey } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'getClaimableRewards',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address && contracts.cms !== '0x',
      refetchInterval: 15000,
    },
  });

  const { data: maxClaimable } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'getMaxClaimable',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address && contracts.cms !== '0x',
      refetchInterval: 15000,
    },
  });

  const { data: remaining, queryKey: remainingKey } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'getRemainingSubscriptions',
    query: {
      enabled: contracts.cms !== '0x',
      refetchInterval: 15000,
    },
  });

  // True when subscription period has ended (deadline passed OR 10k cap reached)
  const { data: subscriptionEnded } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'isSubscriptionEnded',
    query: {
      enabled: contracts.cms !== '0x',
      refetchInterval: 15000,
    },
  });

  // Subscribe deadline timestamp (unix seconds)
  const { data: subscribeDeadline } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'SUBSCRIBE_DEADLINE',
    query: {
      enabled: contracts.cms !== '0x',
    },
  });

  // Claim deadline timestamp (unix seconds)
  const { data: claimDeadline } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'CLAIM_DEADLINE',
    query: {
      enabled: contracts.cms !== '0x',
    },
  });

  // Claim deadline passed?
  const { data: claimDeadlinePassed } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'isClaimDeadlinePassed',
    query: {
      enabled: contracts.cms !== '0x',
      refetchInterval: 30000,
    },
  });

  // Excess rewards that would be deleted on claim (risk indicator)
  const { data: excessToBeDeleted } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'getExcessToBeDeleted',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address && contracts.cms !== '0x',
      refetchInterval: 15000,
    },
  });

  // CMS-specific direct referral count
  const { data: cmsDirects } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'cmsDirectCount',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address && contracts.cms !== '0x',
      refetchInterval: 30000,
    },
  });

  // Has user already claimed?
  const { data: hasAlreadyClaimed } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'hasClaimed',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address && contracts.cms !== '0x',
      refetchInterval: 15000,
    },
  });

  // Aggregated can-claim check (considers deadlines, stake requirement, already claimed)
  const { data: canClaimRewards } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'canClaim',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address && contracts.cms !== '0x',
      refetchInterval: 15000,
    },
  });

  // Per-level leadership details (subs + rewards per level)
  const { data: levelDetails, queryKey: levelDetailsKey } = useReadContract({
    address: contracts.cms,
    abi: CoreMembershipSubscriptionABI,
    functionName: 'getLevelDetails',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address && contracts.cms !== '0x',
      refetchInterval: 15000,
    },
  });

  const { writeContract: writeSubscribe, isPending: subscribePending, data: subscribeHash } = useWriteContract();
  const { writeContract: writeClaim, isPending: claimPending, data: claimHash } = useWriteContract();

  const { isSuccess: subscribeSuccess, isError: subscribeError } = useWaitForTransactionReceipt({ hash: subscribeHash });
  const { isSuccess: claimSuccess, isError: claimError } = useWaitForTransactionReceipt({ hash: claimHash });

  // Refetch all data after successful subscribe
  useEffect(() => {
    if (subscribeSuccess) {
      toast({ type: 'success', title: 'Subscribed successfully!' });
      queryClient.invalidateQueries({ queryKey: totalSubsKey });
      queryClient.invalidateQueries({ queryKey: userSubCountKey });
      queryClient.invalidateQueries({ queryKey: remainingKey });
      queryClient.invalidateQueries({ queryKey: claimableKey });
      queryClient.invalidateQueries({ queryKey: levelDetailsKey });
    }
  }, [subscribeSuccess]);
  useEffect(() => { if (subscribeError) toast({ type: 'error', title: 'Subscription failed' }); }, [subscribeError]);

  // Refetch after successful claim
  useEffect(() => {
    if (claimSuccess) {
      toast({ type: 'success', title: 'CMS rewards claimed!' });
      queryClient.invalidateQueries({ queryKey: claimableKey });
    }
  }, [claimSuccess]);
  useEffect(() => { if (claimError) toast({ type: 'error', title: 'Claim failed' }); }, [claimError]);

  const subscribe = (amount: bigint, referrer: string) => {
    writeSubscribe({
      address: contracts.cms,
      abi: CoreMembershipSubscriptionABI,
      functionName: 'subscribe',
      args: [amount, referrer as `0x${string}`],
    });
    toast({ type: 'pending', title: 'Subscribing to CMS...' });
  };

  const claimRewards = () => {
    writeClaim({
      address: contracts.cms,
      abi: CoreMembershipSubscriptionABI,
      functionName: 'claimCMSRewards',
    });
    toast({ type: 'pending', title: 'Claiming CMS rewards...' });
  };

  return {
    totalSubscriptions: Number(totalSubs || 0),
    userSubscriptionCount: Number(userSubCount || 0),
    remainingSubscriptions: Number(remaining || 0),
    isSubscriptionEnded: subscriptionEnded === true,
    subscribeDeadline: subscribeDeadline ? Number(subscribeDeadline) : 0,
    claimDeadline: claimDeadline ? Number(claimDeadline) : 0,
    isClaimDeadlinePassed: claimDeadlinePassed === true,
    excessToBeDeleted: excessToBeDeleted as bigint | undefined,
    excessToBeDeletedFormatted: excessToBeDeleted ? formatUnits(excessToBeDeleted as bigint, KAIRO_DECIMALS) : '0',
    cmsDirectCount: cmsDirects != null ? Number(cmsDirects) : 0,
    hasAlreadyClaimed: hasAlreadyClaimed === true,
    canClaimRewards: (canClaimRewards as any)?.[0] === true,
    claimableRewards: claimable as any,
    maxClaimable: maxClaimable as bigint | undefined,
    // Total available rewards from subscriptions (loyalty + leadership)
    availableFormatted: claimable ? formatUnits((claimable as readonly bigint[])[2] ?? BigInt(0), KAIRO_DECIMALS) : '0',
    loyaltyFormatted: claimable ? formatUnits((claimable as readonly bigint[])[0] ?? BigInt(0), KAIRO_DECIMALS) : '0',
    leadershipFormatted: claimable ? formatUnits((claimable as readonly bigint[])[1] ?? BigInt(0), KAIRO_DECIMALS) : '0',
    // Max claimable KAIRO capped by active stake value
    maxClaimableFormatted: maxClaimable ? formatUnits(maxClaimable as bigint, KAIRO_DECIMALS) : '0',
    // Legacy alias
    claimableFormatted: claimable ? formatUnits((claimable as readonly bigint[])[2] ?? BigInt(0), KAIRO_DECIMALS) : '0',
    // Per-level details: [subs[5], rewards[5]]
    levelDetails: levelDetails as readonly [readonly bigint[], readonly bigint[]] | undefined,
    subscribe,
    claimRewards,
    isLoading: countLoading,
    isPending: subscribePending || claimPending,
  };
}
